﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _16_09_2019.Models
{
    public class Telesuk
    {
        public int Id { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Adress { get; set; }

        public int Age { get; set; }

        public bool IsMarried { get; set; }
    }
}
